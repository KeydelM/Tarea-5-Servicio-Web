Tarea #5 de programacion web.  

![image](https://github.com/user-attachments/assets/7d981d0d-a43f-4811-bff7-84669cb005a5)
![image](https://github.com/user-attachments/assets/19912c4a-406f-4fe8-a87e-528a3e3cea45)
![image](https://github.com/user-attachments/assets/f2f5f727-7e3a-4f38-8bd1-642fb5556c21)

